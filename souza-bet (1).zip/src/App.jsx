import React from 'react'

export default function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Souza Bet - Modo Teste</h1>
      <p>Simule apostas com moeda fictícia e mercados reais!</p>
    </div>
  )
}